import pygame, sys, time
from pygame.locals import *

pygame.init()

FPS = 40 # frames per second setting
fpsClock = pygame.time.Clock()

# set up the window
DISPLAYSURF = pygame.display.set_mode((400, 300), 0, 32)
pygame.display.set_caption('Animation')

WHITE = (255, 255, 255)

print("if you click the mine tutle box he will explode")

cat = pygame.image.load("car.png")
catx = 10
caty = 10
direction = 'right'
s=15
explodetick=0
move=True
while True: # the main game loop
    DISPLAYSURF.fill(WHITE)
    #for event in pygame.event.get():
    #     
    if explodetick>0:
        explodetick+=1
    if explodetick==81: 
        pygame.quit()
if move:
    if direction == 'right':
        catx += s
        if catx == 280:
            direction = 'down'
    elif direction == 'down':
        caty += s
        if caty == 220:
            direction = 'left'
    elif direction == 'left':
        catx -= s
        if catx == 10:
            direction = 'up'
    elif direction == 'up':
        caty -= s
        if caty == 10:
            direction = 'right'
DISPLAYSURF.blit(cat, (catx, caty))

for event in pygame.event.get():
    if event.type == QUIT:
        pygame.quit()
        sys.exit()
    if event.type == MOUSEBUTTONDOWN:
        cat = pygame.image.load("car2.png")
        pygame.display.update()
        explodetick=1
        move=False

pygame.display.update()
fpsClock.tick(FPS)